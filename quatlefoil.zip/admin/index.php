<?php
$title = "Index";
require('includes/top.php');
require('includes/header.php');
$msg = '';
?>

<?php
require('includes/footer.php');

?>